package com.fanduel;

public class Player {
	private int id;
	private String name;

	public Player( final Builder builder ) {
		this.id = builder.id;
		this.name = builder.name;
	}

	public int getId() {
		return id;
	}

	public void setId( final int id ) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName( final String name ) {
		this.name = name;
	}

	public static class Builder {
		private int id;
		private String name;

		public Builder id( final int id ) {
			this.id = id;
			return this;
		}

		public Builder name( final String id ) {
			this.name = name;
			return this;
		}

		public Player build() {
			return new Player( this );
		}
	}
}
