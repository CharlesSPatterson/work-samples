package com.fanduel;

public class DepthCharts {

	/**
	 * Adds a player to a depth chart for a given position (at a specific spot). If you
	 * are entering two players into the same slot, the last player entered gets priority and bumps
	 * the existing player down a depth spot.
	 * @param player
	 * @param position
	 * @param depth
	 */
	public void addPlayerToDepthChart( final Player player, final String position,
			final int depth ) {
		// TODO implement me
	}

	/**
	 * Adds a player to the end of the depth chart for a given position.
	 * @param player
	 * @param position
	 */
	public void addPlayerToDepthChart( final Player player, final String position ) {
		// TODO implement me
	}

	/**
	 * Removes a player from the depth chart for a position
	 * @param player
	 * @param position
	 */
	public void removePlayerFromDepthChart( final Player player, final String position ) {
		// TODO implement me
	}

	/**
	 * Prints out all depth chart positions
	 */
	public void getFullDepthChart() {
		// TODO implement me
	}

	/**
	 * For a given player find all players below them on the depth chart.
	 * @param player
	 * @param position
	 */
	public void getPlayersUnderPlayerInDepthChart( final Player player, final String position ) {
		// TODO implement me
	}
}
